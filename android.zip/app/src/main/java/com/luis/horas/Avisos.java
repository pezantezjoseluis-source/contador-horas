package com.luis.horas;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class Avisos extends BroadcastReceiver {
    static final String CANAL = "recordatorios";
    static final String ACCION = "com.luis.horas.AVISO";

    @Override
    public void onReceive(Context c, Intent i) {
        String tipo = i.getStringExtra("tipo");
        if ("estudio".equals(tipo)) avisoEstudio(c, i.getStringExtra("id"));
        else if ("semanal".equals(tipo)) resumenSemanal(c);
        else if ("mensual".equals(tipo)) avisoMensual(c);
        programar(c);
    }

    static JSONObject datos(Context c) {
        try {
            return new JSONObject(c.getSharedPreferences("horas", Context.MODE_PRIVATE).getString("datos", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    static void crearCanal(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CANAL, "Recordatorios", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Estudios bíblicos y resumen semanal de horas");
            c.getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    static void notificar(Context c, int id, String titulo, String texto) {
        notificar(c, id, titulo, texto, null);
    }

    static void notificar(Context c, int id, String titulo, String texto, String abrir) {
        crearCanal(c);
        Intent abrirApp = new Intent(c, MainActivity.class);
        abrirApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (abrir != null) abrirApp.putExtra("abrir", abrir);
        PendingIntent pi = PendingIntent.getActivity(c, id, abrirApp,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, CANAL) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.notif)
                .setContentTitle(titulo)
                .setContentText(texto)
                .setStyle(new Notification.BigTextStyle().bigText(texto))
                .setColor(0xFF2F6B5E)
                .setAutoCancel(true)
                .setContentIntent(pi);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH);
        try {
            c.getSystemService(NotificationManager.class).notify(id, b.build());
        } catch (SecurityException e) {
            // sin permiso de notificaciones
        }
    }

    static void avisoEstudio(Context c, String id) {
        if (id == null) return;
        JSONObject d = datos(c);
        String[] listas = {"estudios", "revisitas"};
        for (String nombreLista : listas) {
            JSONArray es = d.optJSONArray(nombreLista);
            if (es == null) continue;
            boolean rev = nombreLista.equals("revisitas");
            for (int k = 0; k < es.length(); k++) {
                JSONObject e = es.optJSONObject(k);
                if (e == null || !id.equals(e.optString("id"))) continue;
                StringBuilder t = new StringBuilder("Hoy a las " + e.optString("hora"));
                if (rev && e.optString("direccion").length() > 0) t.append(" · ").append(e.optString("direccion"));
                if (e.optString("tema").length() > 0) t.append(" · ").append(e.optString("tema"));
                if (e.optString("notas").length() > 0) t.append("\n").append(e.optString("notas"));
                String titulo = rev ? "🏠 Revisita: " + e.optString("nombre") : "📖 Estudio con " + e.optString("nombre");
                notificar(c, codigo(id), titulo, t.toString());
                return;
            }
        }
    }

    static final String[] MESES = {"enero", "febrero", "marzo", "abril", "mayo", "junio", "julio",
            "agosto", "septiembre", "octubre", "noviembre", "diciembre"};

    static void avisoMensual(Context c) {
        Calendar x = Calendar.getInstance();
        x.add(Calendar.MONTH, -1);
        String mes = MESES[x.get(Calendar.MONTH)];
        notificar(c, 2, "👋 Hola, no te olvides de entregar tu informe mensual",
                "Toca aquí y tu informe de " + mes + " se abre ya sumado y listo para enviar por WhatsApp. "
                        + "Aprovecha también para guardar tu copia de respaldo 💾", "informe");
    }

    static long proximoDia1(int hora) {
        Calendar x = Calendar.getInstance();
        x.set(Calendar.DAY_OF_MONTH, 1);
        x.set(Calendar.HOUR_OF_DAY, hora);
        x.set(Calendar.MINUTE, 0);
        x.set(Calendar.SECOND, 0);
        x.set(Calendar.MILLISECOND, 0);
        if (x.getTimeInMillis() <= System.currentTimeMillis() + 1000) x.add(Calendar.MONTH, 1);
        return x.getTimeInMillis();
    }

    static String fmt(long min) {
        long h = min / 60, m = min % 60;
        return m == 0 ? h + " h" : h + " h " + m + " min";
    }

    static void resumenSemanal(Context c) {
        JSONObject d = datos(c);
        int meta = d.optInt("meta", 50);
        JSONArray rs = d.optJSONArray("registros");
        if (rs == null) rs = new JSONArray();
        Calendar hoy = Calendar.getInstance();
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        String mes = new SimpleDateFormat("yyyy-MM", Locale.US).format(hoy.getTime());
        Calendar ini = (Calendar) hoy.clone();
        ini.add(Calendar.DAY_OF_MONTH, -6);
        String desde = f.format(ini.getTime()), hasta = f.format(hoy.getTime());
        long tMes = 0, tSem = 0;
        for (int k = 0; k < rs.length(); k++) {
            JSONObject r = rs.optJSONObject(k);
            if (r == null) continue;
            String fe = r.optString("fecha");
            long mi = r.optLong("min");
            if (fe.startsWith(mes)) tMes += mi;
            if (fe.compareTo(desde) >= 0 && fe.compareTo(hasta) <= 0) tSem += mi;
        }
        int dias = hoy.getActualMaximum(Calendar.DAY_OF_MONTH), dia = hoy.get(Calendar.DAY_OF_MONTH);
        long metaMin = meta * 60L, esperado = metaMin * dia / dias;
        String titulo, texto;
        if (tMes >= metaMin) {
            titulo = "🎉 ¡Meta del mes cumplida!";
            texto = "Llevas " + fmt(tMes) + " este mes y esta semana hiciste " + fmt(tSem) + ". ¡Felicidades, sigue así!";
        } else if (tMes >= esperado) {
            titulo = "😊 ¡Vas muy bien con tus horas!";
            texto = "Has cumplido con tus horas: llevas " + fmt(tMes) + " de " + meta + " h y vas adelantado por "
                    + fmt(tMes - esperado) + ". Esta semana hiciste " + fmt(tSem) + ". ¡Felicidades, sigue así!";
        } else {
            titulo = "⏰ Estás retrasado con " + fmt(esperado - tMes);
            texto = "Llevas " + fmt(tMes) + " de " + meta + " h este mes y esta semana hiciste " + fmt(tSem)
                    + ". Te faltan " + fmt(metaMin - tMes) + " para la meta. ¡Tú puedes!";
        }
        notificar(c, 1, titulo, texto);
    }

    static int codigo(String id) {
        return (id.hashCode() & 0x7fffff) + 100;
    }

    static PendingIntent pi(Context c, int code, String tipo, String id) {
        Intent i = new Intent(c, Avisos.class);
        i.setAction(ACCION);
        i.putExtra("tipo", tipo);
        if (id != null) i.putExtra("id", id);
        return PendingIntent.getBroadcast(c, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void alarma(AlarmManager am, long cuando, PendingIntent p) {
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cuando, p);
            else
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cuando, p);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cuando, p);
        }
    }

    // diaSemana: 0 = domingo ... 6 = sábado
    static long proximo(int diaSemana, int hora, int minuto, int antes) {
        long ahora = System.currentTimeMillis();
        for (int k = 0; k <= 14; k++) {
            Calendar x = Calendar.getInstance();
            x.add(Calendar.DAY_OF_MONTH, k);
            if (x.get(Calendar.DAY_OF_WEEK) - 1 != diaSemana) continue;
            x.set(Calendar.HOUR_OF_DAY, hora);
            x.set(Calendar.MINUTE, minuto);
            x.set(Calendar.SECOND, 0);
            x.set(Calendar.MILLISECOND, 0);
            x.add(Calendar.MINUTE, -antes);
            if (x.getTimeInMillis() > ahora + 1000) return x.getTimeInMillis();
        }
        return -1;
    }

    static int[] hm(String s) {
        try {
            String[] p = s.split(":");
            return new int[]{Integer.parseInt(p[0].trim()), Integer.parseInt(p[1].trim())};
        } catch (Exception e) {
            return new int[]{19, 0};
        }
    }

    static synchronized void programar(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        SharedPreferences sp = c.getSharedPreferences("horas", Context.MODE_PRIVATE);
        for (String s : sp.getStringSet("codigos", new HashSet<String>())) {
            try { am.cancel(pi(c, Integer.parseInt(s), "x", null)); } catch (Exception e) { }
        }
        Set<String> nuevos = new HashSet<String>();
        JSONObject d = datos(c);
        JSONObject n = d.optJSONObject("notif");
        boolean semanal = n == null || n.optBoolean("semanal", true);
        if (semanal) {
            int[] h = hm(n == null ? "19:00" : n.optString("hora", "19:00"));
            long t = proximo(0, h[0], h[1], 0);
            if (t > 0) { alarma(am, t, pi(c, 1, "semanal", null)); nuevos.add("1"); }
        }
        if (n == null || n.optBoolean("mensual", true)) {
            alarma(am, proximoDia1(9), pi(c, 2, "mensual", null));
            nuevos.add("2");
        }
        String[] listas = {"estudios", "revisitas"};
        for (String nombreLista : listas) {
            JSONArray es = d.optJSONArray(nombreLista);
            if (es == null) continue;
            for (int k = 0; k < es.length(); k++) {
                JSONObject e = es.optJSONObject(k);
                if (e == null || !e.optBoolean("aviso", false) || !e.optBoolean("activo", true)) continue;
                String dia = e.optString("dia", ""), hora = e.optString("hora", "");
                if (dia.length() == 0 || hora.length() == 0) continue;
                int ds;
                try { ds = Integer.parseInt(dia); } catch (Exception x) { continue; }
                int[] h = hm(hora);
                String id = e.optString("id");
                int code = codigo(id);
                long t = proximo(ds, h[0], h[1], e.optInt("antes", 60));
                if (t > 0) { alarma(am, t, pi(c, code, "estudio", id)); nuevos.add("" + code); }
            }
        }
        sp.edit().putStringSet("codigos", nuevos).apply();
    }
}
