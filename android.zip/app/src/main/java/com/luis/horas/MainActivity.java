package com.luis.horas;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle estado) {
        super.onCreate(estado);
        getWindow().setStatusBarColor(Color.parseColor("#2F6B5E"));
        Avisos.crearCanal(this);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Puente(), "Android");
        String abrir = getIntent() != null ? getIntent().getStringExtra("abrir") : null;
        web.loadUrl("file:///android_asset/index.html" + ("informe".equals(abrir) ? "#informe" : ""));
        setContentView(web);
    }

    void pedirPermiso() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    class Puente {
        @JavascriptInterface
        public void compartir(String texto) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, "Respaldo Mis Horas");
            i.putExtra(Intent.EXTRA_TEXT, texto);
            startActivity(Intent.createChooser(i, "Enviar respaldo"));
        }

        @JavascriptInterface
        public void sincronizar(String json) {
            getSharedPreferences("horas", MODE_PRIVATE).edit().putString("datos", json).apply();
            Avisos.programar(MainActivity.this);
        }

        @JavascriptInterface
        public boolean sistemaOscuro() {
            return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                    == Configuration.UI_MODE_NIGHT_YES;
        }

        @JavascriptInterface
        public void barra(final String color, final boolean iconosClaros) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        getWindow().setStatusBarColor(Color.parseColor(color));
                        if (Build.VERSION.SDK_INT >= 23) {
                            View d = getWindow().getDecorView();
                            int f = d.getSystemUiVisibility();
                            if (iconosClaros) f &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                            else f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                            d.setSystemUiVisibility(f);
                        }
                    } catch (Exception e) { }
                }
            });
        }

        @JavascriptInterface
        public void copiar(String texto) {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Informe", texto));
        }

        @JavascriptInterface
        public void whatsapp(String texto) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, texto);
            String[] apps = {"com.whatsapp", "com.whatsapp.w4b"};
            for (String app : apps) {
                try {
                    i.setPackage(app);
                    startActivity(i);
                    return;
                } catch (ActivityNotFoundException e) { }
            }
            i.setPackage(null);
            startActivity(Intent.createChooser(i, "Enviar informe"));
        }

        @JavascriptInterface
        public void probar() {
            Avisos.resumenSemanal(MainActivity.this);
        }

        @JavascriptInterface
        public void permiso() {
            runOnUiThread(new Runnable() {
                public void run() { pedirPermiso(); }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
